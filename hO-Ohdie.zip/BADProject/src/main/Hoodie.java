package main;

public class Hoodie {

	private String hoodieIdHome;
	private String hoodieNameHome;
	
	public Hoodie(String hoodieIdHome, String hoodieNameHome) {
		super();
		this.hoodieIdHome = hoodieIdHome;
		this.hoodieNameHome = hoodieNameHome;
	}
	public String getHoodieIdHome() {
		return hoodieIdHome;
	}
	public void setHoodieIdHome(String hoodieIdHome) {
		this.hoodieIdHome = hoodieIdHome;
	}
	public String getHoodieNameHome() {
		return hoodieNameHome;
	}
	public void setHoodieNameHome(String hoodieNameHome) {
		this.hoodieNameHome = hoodieNameHome;
	}
	
	
}
