module BADProjectRevisi {
	opens main;
	requires javafx.graphics;
	requires javafx.controls;
	requires java.sql;
//	requires jfxtras.labs;
}